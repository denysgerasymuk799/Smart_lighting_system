/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
unsigned char letter_to_morse [][3] = {
    {'a', 0x02, 2},
    {'b', 0x01, 4},
    {'c', 0x05, 4},
    {'d', 0x01, 3},
    {'e', 0x00, 1},
    {'f', 0x04, 4},
    {'h', 0x00, 4},
    {'l', 0x02, 4},
    {'o', 0x07, 3},
    {'r', 0x02, 3},
    {'w', 0x06, 3}
};

/* [] END OF FILE */
